'use client';

import { useState, useEffect } from "react";
import { io, Socket } from "socket.io-client";
import { v4 as uuidv4 } from "uuid"; 
let socket: Socket;

export default function ControllerPage() {
  const [time, setTime] = useState("");
  const [destinationThai, setDestinationThai] = useState("");
  const [destinationEng, setDestinationEng] = useState("");

  useEffect(() => {
    socket = io("http://192.168.1.225:4000");
    return () => {
      socket.disconnect();
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!time || !destinationThai || !destinationEng) return;

    socket.emit("addRow", {
      id: uuidv4(),
      time,
      destinationThai,
      destinationEng,
    });

    setTime("");
    setDestinationThai("");
    setDestinationEng("");
  };

  const handleNext = () => {
    socket.emit("nextRow");
  };
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-6">
      <h1 className="text-2xl font-bold mb-6">📋 PID Controller UI</h1>

      <form onSubmit={handleSubmit} className="bg-gray-800 p-6 rounded-xl shadow-md w-full max-w-md">
        <div className="mb-4">
          <label className="block mb-2">⏰ เวลา</label>
          <input
            type="time"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="w-full p-2 rounded bg-gray-700 border border-gray-600 text-white"
          />
        </div>

        <div className="mb-4">
          <label className="block mb-2">📍 ปลายทาง (ภาษาไทย)</label>
          <input
            type="text"
            value={destinationThai}
            onChange={(e) => setDestinationThai(e.target.value)}
            className="w-full p-2 rounded bg-gray-700 border border-gray-600 text-white"
            placeholder="เช่น หลักสอง, บางโพ"
          />
        </div>

        <div className="mb-4">
          <label className="block mb-2">📍 Destination (English)</label>
          <input
            type="text"
            value={destinationEng}
            onChange={(e) => setDestinationEng(e.target.value)}
            className="w-full p-2 rounded bg-gray-700 border border-gray-600 text-white"
            placeholder="e.g. Lak Song, Bang Pho"
          />
        </div>

        <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 py-2 rounded-lg font-semibold transition">
          ➕ เพิ่มตาราง
        </button>
      </form>

      <button onClick={handleNext} className="mt-6 bg-green-600 hover:bg-green-500 py-2 px-6 rounded-lg font-semibold transition">
        ⏭️ เลื่อนไปบรรทัดถัดไป
      </button>
    </div>
  );
}
