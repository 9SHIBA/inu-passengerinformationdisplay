'use client';

import { useState, useEffect } from 'react';
import { io, Socket } from 'socket.io-client';

type RowInfo = {
  id: string;
  time: string;
  destinationThai: string;
  destinationEng: string;
};

let socket: Socket;

export default function BusPlatformBoard() {
  const [showThai, setShowThai] = useState(true);
  const [rows, setRows] = useState<RowInfo[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setShowThai((prev) => !prev);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    socket = io("http://192.168.1.225:4000"); // เปลี่ยนเป็น IP จริงของ server

    socket.on("updateTable", (newRows: RowInfo[]) => {
      setRows(newRows.slice(0, 5));
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="h-screen w-screen flex flex-col bg-gradient-to-b from-gray-900 to-black">
      <div className="bg-gray-800 py-8 text-center shadow-lg">
        <h1 className="text-6xl font-bold text-yellow-300">
          {showThai ? "ชานชาลา 3" : "Platform 3"}
        </h1>
      </div>

      <div className="flex-1 flex items-center justify-center">
        <table className="w-11/12 h-5/6 border-collapse text-white text-4xl">
          <thead>
            <tr className="bg-gray-800 text-yellow-300">
              <th className="py-6 px-8 text-left w-1/3">{showThai ? "เวลา" : "Time"}</th>
              <th className="py-6 px-8 text-left">{showThai ? "ปลายทาง" : "Destination"}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => (
              <tr key={row.id} className={`${idx % 2 === 0 ? "bg-gray-700" : "bg-gray-600"} hover:bg-gray-500 transition`}>
                <td className="py-8 px-8 font-bold text-green-300">{row.time}</td>
                <td className="py-8 px-8">{showThai ? row.destinationThai : row.destinationEng}</td>
              </tr>
            ))}
            {Array.from({ length: Math.max(0, 5 - rows.length) }).map((_, idx) => (
              <tr key={`empty-${idx}`} className="bg-gray-700">
                <td className="py-8 px-8">&nbsp;</td>
                <td className="py-8 px-8">&nbsp;</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
