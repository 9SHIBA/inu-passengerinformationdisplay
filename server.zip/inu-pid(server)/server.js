// server.js
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

let rows = [];

io.on("connection", (socket) => {
  console.log("✅ Client connected");

  socket.emit("updateTable", rows);

  socket.on("addRow", (data) => {
    console.log("📥 Received row:", data);
    if (data.id && data.time && data.destinationThai && data.destinationEng) {
      rows.push(data);
      io.emit("updateTable", rows);
    }
  });

  socket.on("nextRow", () => {
    rows.shift();
    io.emit("updateTable", rows);
  });
});

server.listen(4000, () => {
  console.log("🚀 Server running on http://localhost:4000");
});
